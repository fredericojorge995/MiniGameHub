# MinigameHub - Compilador Automático

## Como compilar o plugin (sem instalar nada!)

### Passo 1: Criar repositório no GitHub

1. Acesse [github.com](https://github.com) e faça login
2. Clique em **New repository** (botão verde)
3. Nome: `MinigameHub` (ou qualquer nome)
4. Marque **Public** (precisa ser público pro Actions funcionar)
5. Clique **Create repository**

### Passo 2: Enviar os arquivos

No celular, baixe este ZIP e extraia. Depois:

1. No seu repositório novo, clique em **uploading an existing file**
2. Arraste TODOS os arquivos do projeto
3. Clique **Commit changes**

### Passo 3: Compilar

1. Clique na aba **Actions** (no topo do repositório)
2. Você vai ver uma mensagem dizendo que não tem workflows ainda
3. Clique em **Create your first workflow** OU clique em **New workflow**
4. Selecione **Build Plugin** (vai aparecer porque criamos o `.github/workflows/build.yml`)
5. Clique no botão **Run workflow** (botão roxo à direita)
6. Aguarde ~2 minutos

### Passo 4: Baixar o JAR

1. Quando o workflow terminar (mostra ✓ verde), clique nele
2. Clique em **Artifacts** no menu lateral
3. Clique em **MinigameHub-1.0**
4. O download vai começar automaticamente

### Passo 5: Instalar no servidor

1. Renomeie o arquivo para `MinigameHub-1.0.jar` (se necessário)
2. Copie para a pasta `plugins/` do seu servidor
3. Reinicie o servidor

---

## Estrutura dos arquivos

```
MinigameHub/
├── .github/
│   └── workflows/
│       └── build.yml      ← Compila automaticamente
├── src/
│   └── main/
│       ├── java/
│       │   └── com/minigamehub/
│       │       ├── MinigameHub.java
│       │       ├── commands/
│       │       ├── games/
│       │       ├── listeners/
│       │       ├── managers/
│       │       ├── utils/
│       │       └── worlds/
│       └── resources/
│           ├── plugin.yml
│           └── config.yml
├── pom.xml
└── README.md
```

---

## Comandos do Plugin

| Comando | Descrição |
|---------|-----------|
| `/warp <minigame>` | Entra no lobby |
| `/hub` | Volta ao hub |
| `/mghelp` | Lista de comandos |
| `/start` | Inicia a partida |
| `/mapvote <1-6>` | Vota num mapa |

**Minigames:** bedwars, skywars, tntrun, spleef, buildbattle, hideseek, hideseekmorph, murdermystery

---

Feito com ❤️ para funcionar sem Java no seu PC!