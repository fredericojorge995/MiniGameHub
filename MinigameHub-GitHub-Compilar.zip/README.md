# MinigameHub - Plugin Minecraft

Hub completo com 8 minigames para Paper/Spigot 1.21.x

## Como compilar (sem instalar nada!)

### 1️⃣ Crie um repositório no GitHub
- Acesse [github.com](https://github.com)
- Clique **New repository**
- Nome: qualquer um (ex: `MinigameHub`)
- Marque **Public**
- Clique **Create repository**

### 2️⃣ Envie os arquivos
- Clique em **uploading an existing file**
- Arraste todos os arquivos deste projeto
- Clique **Commit changes**

### 3️⃣ Compile
- Clique na aba **Actions** (no topo)
- Você verá o workflow **Build Plugin**
- Clique **Run workflow** (botão roxo à direita)
- Aguarde ~2 minutos

### 4️⃣ Baixe o JAR
- Quando aparecer ✓ verde, clique nele
- Clique em **Artifacts**
- Clique em **MinigameHub-1.0**
- O JAR vai baixar

### 5️⃣ Instale no servidor
- Cole o arquivo na pasta `plugins/`
- Reinicie o servidor

---

## Comandos do Plugin

| Comando | Descrição | Permissão |
|---------|-----------|-----------|
| `/warp <minigame>` | Entra no lobby | - |
| `/hub` | Volta ao hub | - |
| `/mghelp` | Lista comandos | - |
| `/start` | Inicia partida | minigamehub.start |
| `/mapvote <1-6>` | Vota mapa | - |
| `/setspawn` | Define spawn | minigamehub.admin |
| `/mgreload` | Recarrega config | minigamehub.admin |

**Minigames:** bedwars, skywars, tntrun, spleef, buildbattle, hideseek, hideseekmorph, murdermystery