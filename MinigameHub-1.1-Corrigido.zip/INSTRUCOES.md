# MinigameHub v1.1 - Correções e Melhorias

## Problemas Identificados e Corrigidos

### 1. **NPE (NullPointerException) na Main Class**
- **Problema**: A classe principal não tinha import do ChatColor, causando erro ao compilar
- **Solução**: Adicionado `import org.bukkit.ChatColor;`

### 2. **Código de cores faltante no plugin.yml**
- **Problema**: Os códigos de cores `&` não eram traduzidos corretamente
- **Solução**: Usar MsgUtil.color() para converter cores

### 3. **Falha ao carregar minigames do config**
- **Problema**: Erro ao ler ConfigurationSection null
- **Solução**: Verificações de null safety adicionadas em MinigameManager

### 4. **Criação de mundos sem verificação**
- **Problema**: Tentava criar mundos sem verificar se já existiam
- **Solução**: WorldManager agora verifica e carrega mundos existentes

### 5. **Comandos não registrados corretamente**
- **Problema**: getCommand() podia retornar null
- **Solução**: Verificação de null antes de setExecutor()

### 6. **ArenaSession inner class com problemas**
- **Problema**: Referência à classe externa não estava funcionando
- **Solução**: Estrutura reorganizada para evitar vazamentos de memória

### 7. **Player teleported antes do mundo existir**
- **Problema**: Teleportava jogadores para mundos ainda não carregados
- **Solução**: Adicionado delay e verificação de mundo válido

### 8. **Votação em mapa sem validação**
- **Problema**: Não verificava se o índice do mapa era válido
- **Solução**: Validação de limites adicionada em MapVoteCommand

## Arquivos Corrigidos

### Core
- `MinigameHub.java` - Import corrigido, null safety
- `Minigame.java` - Getter para maps com validação

### Managers
- `MinigameManager.java` - LoadAll com tratamento de exceções
- `ArenaManager.java` - Estrutura de sessão reorganizada
- `WorldManager.java` - Verificação de mundos, plataformas melhoradas

### Commands
- `WarpCommand.java` - Validação de minigame, null safety
- `HubCommand.java` - Simples e funcional
- `MgHelpCommand.java` - Listagem de minigames
- `StartCommand.java` - Verificação de jogadores suficientes
- `MapVoteCommand.java` - Validação de input
- `SetSpawnCommand.java` - Salvar spawn no config
- `MgReloadCommand.java` - Recarregar configurações

### Utils
- `MsgUtil.java` - Utilitário para mensagens com cores

### Listeners
- `PlayerListener.java` - Eventos de Join/Quit/Respawn

### Worlds
- `EmptyChunkGenerator.java` - Gerador de mundos vazios

## Como Compilar

### Requisitos
- Java 17 ou superior
- Maven 3.6+

### Passos
```bash
# 1. Navegue até o diretório do projeto
cd MinigameHub_Source

# 2. Compile com Maven
mvn clean package -DskipTests

# 3. O JAR estará em:
#    target/MinigameHub-1.0.jar

# 4. Copie para a pasta plugins do seu servidor
```

### Alternativa (sem Maven)
```bash
# Compile manualmente
mkdir -p out
javac -cp spigot-api.jar -d out src/main/java/com/minigamehub/*.java
javac -cp spigot-api.jar -d out src/main/java/com/minigamehub/**/*.java
jar cf MinigameHub-1.0.jar -C out .
```

## Instalação no Servidor

1. Pare o servidor
2. Remova o JAR antigo: `rm plugins/MinigameHub-1.0.jar`
3. Copie o novo JAR para `plugins/`
4. Inicie o servidor
5. Aguarde a criação dos mundos (30-60 segundos)
6. Use `/mghelp` para verificar se está funcionando

## Comandos Disponíveis

| Comando | Descrição | Permissão |
|---------|-----------|-----------|
| `/warp <minigame>` | Entra no lobby | - |
| `/warp hub` | Volta ao hub | - |
| `/hub` | Volta ao hub (atalho) | - |
| `/mghelp` | Lista de comandos | - |
| `/start` | Inicia a partida | minigamehub.start |
| `/mapvote <1-6>` | Vota em um mapa | - |
| `/setspawn` | Define spawn | minigamehub.admin |
| `/mgreload` | Recarrega config | minigamehub.admin |

## Minigames Disponíveis

- **bedwars** - Batalha em equipes protegendo camas
- **skywars** - Skyblock PvP
- **tntrun** - Corra antes dos blocos desaparecerem
- **spleef** - Destrua blocos sob os jogadores
- **buildbattle** - Construa e vote no melhor
- **hideseek** - Esconde-esconde
- **hideseekmorph** - Esconde-esconde com morphs
- **murdermystery** - Encontre o assassino

---

**Versão 1.1** - Todas as correções aplicadas