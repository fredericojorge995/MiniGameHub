package com.minigamehub.commands;

import com.minigamehub.MinigameHub;
import com.minigamehub.managers.ArenaManager;
import com.minigamehub.utils.MsgUtil;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class WarpCommand implements CommandExecutor {

    private final MinigameHub plugin;

    public WarpCommand(MinigameHub plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + \"Apenas jogadores.\");
            return true;
        }

        Player player = (Player) sender;

        if (args.length == 0) {
            player.sendMessage(ChatColor.RED + \"Use: /warp <minigame|hub>\");
            player.sendMessage(ChatColor.GRAY + \"Minigames: bedwars, skywars, tntrun, spleef, buildbattle, hideseek, hideseekmorph, murdermystery\");
            return true;
        }

        String target = args[0].toLowerCase();

        if (target.equals(\"hub\")) {
            plugin.getArenaManager().sendToHub(player);
            return true;
        }

        var minigame = plugin.getMinigameManager().get(target);
        if (minigame == null) {
            MsgUtil.send(player, plugin.getConfig().getString(\"messages.warp-not-found\", \"&cMinigame nao encontrado!\"));
            return true;
        }

        plugin.getArenaManager().joinLobby(player, minigame);
        
        String msg = plugin.getConfig().getString(\"messages.warp-success\", \"&aTeleportando para &e%target%&a...\");
        MsgUtil.send(player, msg.replace(\"%target%\", minigame.getDisplayName()));

        return true;
    }
}