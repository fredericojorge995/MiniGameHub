package com.minigamehub.commands;

import com.minigamehub.MinigameHub;
import com.minigamehub.managers.ArenaManager;
import com.minigamehub.managers.ArenaManager.ArenaSession;
import com.minigamehub.utils.MsgUtil;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class StartCommand implements CommandExecutor {

    private final MinigameHub plugin;

    public StartCommand(MinigameHub plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission(\"minigamehub.start\")) {
            MsgUtil.send(sender, plugin.getConfig().getString(\"messages.no-permission\", \"&cVoce nao tem permissao!\"));
            return true;
        }

        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + \"Apenas jogadores.\");
            return true;
        }

        Player player = (Player) sender;
        String arenaKey = plugin.getArenaManager().getPlayerArena(player);

        if (arenaKey == null) {
            MsgUtil.send(player, ChatColor.RED + \"Voce nao esta em nenhum lobby!\");
            return true;
        }

        ArenaSession session = plugin.getArenaManager().getSession(arenaKey);
        if (session == null) {
            MsgUtil.send(player, ChatColor.RED + \"Sessao nao encontrada.\");
            return true;
        }

        int minPlayers = plugin.getConfig().getInt(\"lobby.min-players\", 2);
        int playerCount = session.getPlayerCount();

        if (playerCount < minPlayers) {
            MsgUtil.send(player, plugin.getConfig().getString(\"messages.not-enough-players\", \"&cJogadores insuficientes para iniciar!\"));
            player.sendMessage(ChatColor.GRAY + \"Minimo necessario: \" + ChatColor.YELLOW + minPlayers + ChatColor.GRAY + \" jogadores\");
            return true;
        }

        // Iniciar o jogo
        plugin.getArenaManager().startGame(arenaKey);
        MsgUtil.send(player, plugin.getConfig().getString(\"messages.game-start\", \"&aA partida vai comecar!\"));

        return true;
    }
}