package com.minigamehub.commands;

import com.minigamehub.MinigameHub;
import com.minigamehub.managers.ArenaManager;
import com.minigamehub.managers.ArenaManager.ArenaSession;
import com.minigamehub.utils.MsgUtil;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;

public class MapVoteCommand implements CommandExecutor {

    private final MinigameHub plugin;

    public MapVoteCommand(MinigameHub plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + \"Apenas jogadores.\");
            return true;
        }

        Player player = (Player) sender;

        // Verificar se está em um lobby
        String arenaKey = plugin.getArenaManager().getPlayerArena(player);
        if (arenaKey == null) {
            MsgUtil.send(player, ChatColor.RED + \"Entre em um lobby antes!\");
            player.sendMessage(ChatColor.GRAY + \"Use \" + ChatColor.YELLOW + \"/warp <minigame>\" + ChatColor.GRAY + \" para entrar em um lobby.\");
            return true;
        }

        ArenaSession session = plugin.getArenaManager().getSession(arenaKey);
        if (session == null) {
            MsgUtil.send(player, ChatColor.RED + \"Sessao nao encontrada.\");
            return true;
        }

        // Se não houver argumentos, mostrar os mapas disponíveis
        if (args.length == 0) {
            player.sendMessage(ChatColor.GOLD + \"Mapas disponiveis:\");
            List<String> maps = session.getMinigame().getMaps();
            for (int i = 0; i < maps.size(); i++) {
                String mapName = maps.get(i);
                player.sendMessage(ChatColor.YELLOW + \"  \" + (i + 1) + \". \" + ChatColor.WHITE + mapName);
            }
            player.sendMessage(ChatColor.GRAY + \"Use \" + ChatColor.YELLOW + \"/mapvote <numero>\" + ChatColor.GRAY + \" para votar.\");
            return true;
        }

        // Tentar analisar o número do mapa
        int mapIndex;
        try {
            mapIndex = Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            MsgUtil.send(player, ChatColor.RED + \"Numero invalido.\");
            player.sendMessage(ChatColor.GRAY + \"Use \" + ChatColor.YELLOW + \"/mapvote <1-\" + session.getMinigame().getMaps().size() + \">\");
            return true;
        }

        List<String> maps = session.getMinigame().getMaps();
        if (mapIndex < 1 || mapIndex > maps.size()) {
            MsgUtil.send(player, ChatColor.RED + \"Numero fora do intervalo. Use 1 a \" + maps.size() + \".\");
            return true;
        }

        // Registrar o voto
        session.vote(player, mapIndex);

        return true;
    }
}