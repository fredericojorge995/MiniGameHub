package com.minigamehub.commands;

import com.minigamehub.MinigameHub;
import com.minigamehub.utils.MsgUtil;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class MgReloadCommand implements CommandExecutor {

    private final MinigameHub plugin;

    public MgReloadCommand(MinigameHub plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission(\"minigamehub.admin\")) {
            MsgUtil.send(sender, plugin.getConfig().getString(\"messages.no-permission\", \"&cVoce nao tem permissao!\"));
            return true;
        }

        try {
            // Recarregar config
            plugin.reloadConfig();
            
            // Recarregar minigames
            plugin.getMinigameManager().loadAll();
            
            MsgUtil.send(sender, ChatColor.GREEN + \"Configuracoes recarregadas com sucesso!\");
            sender.sendMessage(ChatColor.GRAY + \"Minigames carregados: \" + ChatColor.YELLOW + plugin.getMinigameManager().all().size());
            
        } catch (Exception e) {
            MsgUtil.send(sender, ChatColor.RED + \"Erro ao recarregar configuracoes!\");
            sender.sendMessage(ChatColor.RED + \"Erro: \" + e.getMessage());
        }

        return true;
    }
}