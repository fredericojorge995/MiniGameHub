package com.minigamehub.commands;

import com.minigamehub.MinigameHub;
import com.minigamehub.utils.MsgUtil;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetSpawnCommand implements CommandExecutor {

    private final MinigameHub plugin;

    public SetSpawnCommand(MinigameHub plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission(\"minigamehub.admin\")) {
            MsgUtil.send(sender, plugin.getConfig().getString(\"messages.no-permission\", \"&cVoce nao tem permissao!\"));
            return true;
        }

        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + \"Apenas jogadores.\");
            return true;
        }

        Player player = (Player) sender;
        String worldName = player.getWorld().getName();

        // Salvar spawn no config
        plugin.getConfig().set(\"worlds.\" + worldName + \".spawn.x\", (int) player.getLocation().getX());
        plugin.getConfig().set(\"worlds.\" + worldName + \".spawn.y\", (int) player.getLocation().getY());
        plugin.getConfig().set(\"worlds.\" + worldName + \".spawn.z\", (int) player.getLocation().getZ());
        plugin.getConfig().set(\"worlds.\" + worldName + \".spawn.yaw\", (int) player.getLocation().getYaw());
        plugin.getConfig().set(\"worlds.\" + worldName + \".spawn.pitch\", (int) player.getLocation().getPitch());
        plugin.saveConfig();

        MsgUtil.send(player, ChatColor.GREEN + \"Spawn definido para este mundo!\");
        player.sendMessage(ChatColor.GRAY + \"Mundo: \" + ChatColor.WHITE + worldName);
        player.sendMessage(ChatColor.GRAY + \"Posicao: \" + ChatColor.WHITE + 
            (int) player.getLocation().getX() + \", \" + 
            (int) player.getLocation().getY() + \", \" + 
            (int) player.getLocation().getZ());

        return true;
    }
}