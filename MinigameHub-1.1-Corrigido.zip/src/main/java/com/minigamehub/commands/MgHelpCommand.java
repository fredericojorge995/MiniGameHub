package com.minigamehub.commands;

import com.minigamehub.MinigameHub;
import com.minigamehub.games.Minigame;
import com.minigamehub.utils.MsgUtil;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import java.util.Collection;

public class MgHelpCommand implements CommandExecutor {

    private final MinigameHub plugin;

    public MgHelpCommand(MinigameHub plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        sender.sendMessage(ChatColor.DARK_GRAY + \"========== \" + ChatColor.GOLD + ChatColor.BOLD + \"MinigameHub\" + ChatColor.DARK_GRAY + \" ==========\");
        
        MsgUtil.sendRaw(sender, ChatColor.YELLOW + \"/warp <minigame> \" + ChatColor.GRAY + \"- Entra no lobby do minigame\");
        MsgUtil.sendRaw(sender, ChatColor.YELLOW + \"/hub \" + ChatColor.GRAY + \"- Volta para o hub principal\");
        MsgUtil.sendRaw(sender, ChatColor.YELLOW + \"/start \" + ChatColor.GRAY + \"- (Admin) Inicia a partida do lobby atual\");
        MsgUtil.sendRaw(sender, ChatColor.YELLOW + \"/mapvote <1-6> \" + ChatColor.GRAY + \"- Vota em um mapa antes do jogo\");
        MsgUtil.sendRaw(sender, ChatColor.YELLOW + \"/setspawn \" + ChatColor.GRAY + \"- (Admin) Define spawn do mundo atual\");
        MsgUtil.sendRaw(sender, ChatColor.YELLOW + \"/mgreload \" + ChatColor.GRAY + \"- (Admin) Recarrega configuracoes\");
        
        sender.sendMessage(\"\");
        sender.sendMessage(ChatColor.GRAY + \"Minigames disponiveis: \" + ChatColor.WHITE + plugin.getMinigameManager().all().size());
        sender.sendMessage(\"\");
        
        Collection<Minigame> minigames = plugin.getMinigameManager().all();
        for (Minigame mg : minigames) {
            String displayName = MsgUtil.color(mg.getDisplayName());
            sender.sendMessage(ChatColor.WHITE + \"  - \" + displayName + ChatColor.GRAY + \" (\" + mg.getKey() + \")\");
        }
        
        sender.sendMessage(ChatColor.DARK_GRAY + \"=================================\");
        return true;
    }
}