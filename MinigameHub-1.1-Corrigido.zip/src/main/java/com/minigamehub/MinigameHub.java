package com.minigamehub;

import com.minigamehub.commands.*;
import com.minigamehub.listeners.PlayerListener;
import com.minigamehub.managers.ArenaManager;
import com.minigamehub.managers.MinigameManager;
import com.minigamehub.managers.WorldManager;
import com.minigamehub.utils.MsgUtil;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class MinigameHub extends JavaPlugin {

    private static MinigameHub instance;
    private WorldManager worldManager;
    private MinigameManager minigameManager;
    private ArenaManager arenaManager;

    @Override
    public void onEnable() {
        instance = this;
        
        // Salvar config padrão se não existir
        saveDefaultConfig();
        
        getLogger().info(getDescription().getFullName());
        getLogger().info(ChatColor.GREEN + \"Inicializando MinigameHub...\");
        
        // Inicializar managers
        this.worldManager = new WorldManager(this);
        this.minigameManager = new MinigameManager(this);
        this.arenaManager = new ArenaManager(this);
        
        // Carregar configuração dos minigames
        minigameManager.loadAll();
        
        // Inicializar todos os mundos (hub, lobbies, mapas)
        worldManager.initializeAllWorlds();
        
        // Registrar eventos
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        
        // Registrar comandos com verificação de null safety
        registerCommand(\"warp\", new WarpCommand(this));
        registerCommand(\"hub\", new HubCommand(this));
        registerCommand(\"mghelp\", new MgHelpCommand(this));
        registerCommand(\"start\", new StartCommand(this));
        registerCommand(\"mapvote\", new MapVoteCommand(this));
        registerCommand(\"setspawn\", new SetSpawnCommand(this));
        registerCommand(\"mgreload\", new MgReloadCommand(this));
        
        getLogger().info(ChatColor.GREEN + \"MinigameHub ativado com sucesso!\");
        getLogger().info(ChatColor.YELLOW + \"8 minigames carregados.\");
    }

    @Override
    public void onDisable() {
        if (worldManager != null) {
            worldManager.saveAllSpawns();
        }
        getLogger().info(\"MinigameHub desativado.\");
    }

    private void registerCommand(String name, org.bukkit.command.CommandExecutor executor) {
        org.bukkit.command.Command cmd = getCommand(name);
        if (cmd != null) {
            cmd.setExecutor(executor);
        } else {
            getLogger().warning(\"Comando nao encontrado: \" + name);
        }
    }

    public static MinigameHub getInstance() {
        return instance;
    }

    public WorldManager getWorldManager() {
        return worldManager;
    }

    public MinigameManager getMinigameManager() {
        return minigameManager;
    }

    public ArenaManager getArenaManager() {
        return arenaManager;
    }
}