package com.minigamehub.managers;

import com.minigamehub.MinigameHub;
import com.minigamehub.games.Minigame;
import com.minigamehub.utils.MsgUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import java.util.*;

public class ArenaManager {

    private final MinigameHub plugin;
    private final Map<String, ArenaSession> sessions = new HashMap<>();
    private final Map<UUID, String> playerArena = new HashMap<>();

    public ArenaManager(MinigameHub plugin) {
        this.plugin = plugin;
    }

    public void joinLobby(Player player, Minigame minigame) {
        if (minigame == null) {
            MsgUtil.send(player, ChatColor.RED + \"Minigame nao encontrado!\");
            return;
        }
        
        // Sair do lobby atual se existir
        if (playerArena.containsKey(player.getUniqueId())) {
            leaveLobby(player, false);
        }
        
        // Obter spawn do lobby
        Location lobbySpawn = minigame.getLobbySpawn();
        if (lobbySpawn == null || lobbySpawn.getWorld() == null) {
            // Criar spawn padrão se não existir
            org.bukkit.World world = Bukkit.getWorld(minigame.getLobbyWorld());
            if (world == null) {
                world = plugin.getWorldManager().createOrLoadWorld(minigame.getLobbyWorld());
            }
            if (world != null) {
                lobbySpawn = new Location(world, 0, 65, 0);
            } else {
                MsgUtil.send(player, ChatColor.RED + \"Lobby ainda nao foi criado! Aguarde a inicializacao.\");
                return;
            }
        }
        
        // Teleportar jogador
        player.teleport(lobbySpawn);
        
        // Registrar na sessão
        String lobbyKey = minigame.getKey();
        ArenaSession session = sessions.computeIfAbsent(lobbyKey, k -> new ArenaSession(minigame));
        session.addPlayer(player);
        playerArena.put(player.getUniqueId(), lobbyKey);
        
        String displayName = minigame.getDisplayName();
        MsgUtil.send(player, ChatColor.GREEN + \"Entrando no lobby de \" + displayName + ChatColor.GREEN + \"...\");
        player.sendMessage(ChatColor.YELLOW + \"Use /start para iniciar a partida quando houverem jogadores suficientes.\");
        player.sendMessage(ChatColor.GRAY + \"Use /mapvote <1-6> para votar em um mapa.\");
        
        // Tocar som
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.0f);
    }

    public void leaveLobby(Player player, boolean sendToHub) {
        String arenaKey = playerArena.remove(player.getUniqueId());
        if (arenaKey != null) {
            ArenaSession session = sessions.get(arenaKey);
            if (session != null) {
                session.removePlayer(player);
            }
        }
        
        if (sendToHub) {
            sendToHub(player);
        }
    }

    public void sendToHub(Player player) {
        String hubWorldName = plugin.getConfig().getString(\"hub.world\", \"hub_main\");
        org.bukkit.World hubWorld = Bukkit.getWorld(hubWorldName);
        
        if (hubWorld == null) {
            hubWorld = plugin.getWorldManager().createOrLoadWorld(hubWorldName);
        }
        
        if (hubWorld == null) {
            MsgUtil.send(player, ChatColor.RED + \"Hub nao encontrado. Contate um administrador.\");
            return;
        }
        
        int x = plugin.getConfig().getInt(\"hub.spawn.x\", 5);
        int y = plugin.getConfig().getInt(\"hub.spawn.y\", 83);
        int z = plugin.getConfig().getInt(\"hub.spawn.z\", -85);
        
        Location hubSpawn = new Location(hubWorld, x, y, z);
        player.teleport(hubSpawn);
        MsgUtil.send(player, ChatColor.YELLOW + \"Bem-vindo ao Hub!\");
    }

    public void startGame(String lobbyKey) {
        ArenaSession session = sessions.get(lobbyKey);
        if (session == null) {
            return;
        }
        
        Minigame minigame = session.getMinigame();
        List<String> maps = minigame.getMaps();
        
        if (maps == null || maps.isEmpty()) {
            plugin.getLogger().warning(\"Nenhum mapa disponivel para \" + minigame.getKey());
            return;
        }
        
        // Escolher mapa mais voted ou aleatorio
        String selectedMap = session.getMostVotedMap();
        if (selectedMap == null) {
            int index = (int) (Math.random() * maps.size());
            selectedMap = maps.get(index);
        }
        
        // Teleportar todos para o mapa
        org.bukkit.World mapWorld = Bukkit.getWorld(selectedMap);
        if (mapWorld == null) {
            mapWorld = plugin.getWorldManager().createOrLoadWorld(selectedMap);
        }
        
        if (mapWorld == null) {
            plugin.getLogger().severe(\"Nao foi possivel carregar o mapa: \" + selectedMap);
            return;
        }
        
        Location mapSpawn = new Location(mapWorld, 0, 66, 0);
        for (Player player : session.getPlayers()) {
            player.teleport(mapSpawn);
            MsgUtil.send(player, ChatColor.GREEN + \"Mapa selecionado: \" + ChatColor.GOLD + selectedMap);
            player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 1.0f);
        }
        
        session.setStarted(true);
        plugin.getLogger().info(\"Jogo iniciado no lobby \" + lobbyKey + \" com mapa \" + selectedMap);
    }

    public String getPlayerArena(Player player) {
        return playerArena.get(player.getUniqueId());
    }

    public ArenaSession getSession(String lobbyKey) {
        return sessions.get(lobbyKey);
    }

    // Inner class ArenaSession
    public class ArenaSession {
        
        private final Set<Player> players = new HashSet<>();
        private final Map<Integer, Integer> votes = new HashMap<>();
        private boolean started = false;
        private final Minigame minigame;

        public ArenaSession(Minigame minigame) {
            this.minigame = minigame;
        }

        public void addPlayer(Player player) {
            players.add(player);
            broadcast(ChatColor.GRAY + player.getName() + \" entrou no lobby. (\" + players.size() + \" jogadores)\");
        }

        public void removePlayer(Player player) {
            players.remove(player);
            broadcast(ChatColor.GRAY + player.getName() + \" saiu do lobby. (\" + players.size() + \" jogadores)\");
        }

        public void vote(Player player, int mapIndex) {
            List<String> maps = minigame.getMaps();
            if (mapIndex < 1 || mapIndex > maps.size()) {
                MsgUtil.send(player, ChatColor.RED + \"Numero invalido. Use /mapvote <1-\" + maps.size() + \">\");
                return;
            }
            
            Integer count = votes.get(mapIndex);
            votes.put(mapIndex, count == null ? 1 : count + 1);
            
            MsgUtil.send(player, ChatColor.GREEN + \"Voto registrado para o mapa \" + mapIndex + \"!\");
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 2.0f);
        }

        public String getMostVotedMap() {
            if (votes.isEmpty()) {
                return null;
            }
            
            int maxVotes = 0;
            int winnerIndex = -1;
            
            for (Map.Entry<Integer, Integer> entry : votes.entrySet()) {
                if (entry.getValue() > maxVotes) {
                    maxVotes = entry.getValue();
                    winnerIndex = entry.getKey();
                }
            }
            
            if (winnerIndex > 0 && winnerIndex <= minigame.getMaps().size()) {
                return minigame.getMaps().get(winnerIndex - 1);
            }
            
            return null;
        }

        public Set<Player> getPlayers() {
            return players;
        }

        public Minigame getMinigame() {
            return minigame;
        }

        public boolean isStarted() {
            return started;
        }

        public void setStarted(boolean started) {
            this.started = started;
        }

        public int getPlayerCount() {
            return players.size();
        }

        private void broadcast(String message) {
            for (Player p : players) {
                p.sendMessage(message);
            }
        }
    }
}