package com.minigamehub.managers;

import com.minigamehub.MinigameHub;
import com.minigamehub.games.Minigame;
import com.minigamehub.worlds.EmptyChunkGenerator;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.configuration.ConfigurationSection;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class WorldManager {

    private final MinigameHub plugin;
    private final Map<String, Location> worldSpawns = new HashMap<>();

    public WorldManager(MinigameHub plugin) {
        this.plugin = plugin;
    }

    public void initializeAllWorlds() {
        plugin.getLogger().info(\"Inicializando mundos...\");
        
        // Criar hub principal
        String hubWorld = plugin.getConfig().getString(\"hub.world\", \"hub_main\");
        plugin.getLogger().info(\"[WorldManager] Criando hub principal: \" + hubWorld);
        createOrLoadWorld(hubWorld);
        buildHubPlatform(Bukkit.getWorld(hubWorld));
        
        // Salvar spawn do hub
        int hubX = plugin.getConfig().getInt(\"hub.spawn.x\", 5);
        int hubY = plugin.getConfig().getInt(\"hub.spawn.y\", 83);
        int hubZ = plugin.getConfig().getInt(\"hub.spawn.z\", -85);
        World hubWorldObj = Bukkit.getWorld(hubWorld);
        if (hubWorldObj != null) {
            worldSpawns.put(hubWorld, new Location(hubWorldObj, hubX, hubY, hubZ));
        }
        
        // Criar lobbies e mapas de todos os minigames
        ConfigurationSection section = plugin.getConfig().getConfigurationSection(\"minigames\");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                ConfigurationSection mg = section.getConfigurationSection(key);
                if (mg == null) continue;

                String lobbyWorld = mg.getString(\"lobby-world\", key + \"_lobby\");
                plugin.getLogger().info(\"[WorldManager] Criando lobby: \" + lobbyWorld);
                
                World lobby = createOrLoadWorld(lobbyWorld);
                if (lobby != null) {
                    buildLobbyPlatform(lobby, key);
                    
                    int x = mg.getInt(\"spawn.x\", 0);
                    int y = mg.getInt(\"spawn.y\", 65);
                    int z = mg.getInt(\"spawn.z\", 0);
                    worldSpawns.put(lobbyWorld, new Location(lobby, x, y, z));
                }
                
                // Criar 6 mapas para cada minigame
                java.util.List<String> maps = mg.getStringList(\"maps\");
                for (int i = 0; i < Math.min(maps.size(), 6); i++) {
                    String mapName = maps.get(i);
                    plugin.getLogger().info(\"[WorldManager] Criando mapa: \" + mapName);
                    World mapWorld = createOrLoadWorld(mapName);
                    if (mapWorld != null) {
                        buildGamePlatform(mapWorld);
                    }
                }
            }
        }
        
        plugin.getLogger().info(\"Todos os mundos inicializados.\");
    }

    public World createOrLoadWorld(String worldName) {
        World world = Bukkit.getWorld(worldName);
        if (world != null) {
            return world;
        }
        
        File worldFolder = new File(Bukkit.getWorldContainer(), worldName);
        if (worldFolder.exists()) {
            // Carregar mundo existente
            return Bukkit.createWorld(new WorldCreator(worldName));
        } else {
            // Criar novo mundo com EmptyChunkGenerator
            WorldCreator creator = new WorldCreator(worldName);
            creator.generator(new EmptyChunkGenerator());
            creator.environment(org.bukkit.World.Environment.NORMAL);
            creator.generateStructures(false);
            return creator.createWorld();
        }
    }

    private void buildHubPlatform(World world) {
        if (world == null) return;
        
        // Construir plataforma central do hub
        int centerX = 0;
        int centerZ = 0;
        
        // Plataforma principal 20x20
        for (int x = -10; x <= 10; x++) {
            for (int z = -10; z <= 10; z++) {
                world.getBlockAt(centerX + x, 65, centerZ + z).setType(Material.STONE);
            }
        }
        
        // Colunas decorativas nos cantos
        for (int y = 66; y <= 70; y++) {
            world.getBlockAt(centerX - 10, y, centerZ - 10).setType(Material.GLOWSTONE);
            world.getBlockAt(centerX + 10, y, centerZ - 10).setType(Material.GLOWSTONE);
            world.getBlockAt(centerX - 10, y, centerZ + 10).setType(Material.GLOWSTONE);
            world.getBlockAt(centerX + 10, y, centerZ + 10).setType(Material.GLOWSTONE);
        }
        
        plugin.getLogger().info(\"Plataforma do hub construída em \" + world.getName());
    }

    private void buildLobbyPlatform(World world, String minigameKey) {
        if (world == null) return;
        
        int centerX = 0;
        int centerZ = 0;
        
        // Plataforma 15x15
        for (int x = -7; x <= 7; x++) {
            for (int z = -7; z <= 7; z++) {
                world.getBlockAt(centerX + x, 65, centerZ + z).setType(Material.IRON_BLOCK);
            }
        }
        
        // Placa central
        world.getBlockAt(centerX, 66, centerZ).setType(Material.END_PORTAL_FRAME);
        
        plugin.getLogger().info(\"Plataforma do lobby \" + minigameKey + \" construída.\");
    }

    private void buildGamePlatform(World world) {
        if (world == null) return;
        
        int centerX = 0;
        int centerZ = 0;
        
        // Plataforma de jogo 30x30
        for (int x = -15; x <= 15; x++) {
            for (int z = -15; z <= 15; z++) {
                world.getBlockAt(centerX + x, 65, centerZ + z).setType(Material.GLASS);
            }
        }
        
        // Borda de blocos sólidos
        for (int x = -15; x <= 15; x++) {
            world.getBlockAt(centerX + x, 64, centerZ - 15).setType(Material.BEDROCK);
            world.getBlockAt(centerX + x, 64, centerZ + 15).setType(Material.BEDROCK);
        }
        for (int z = -15; z <= 15; z++) {
            world.getBlockAt(centerX - 15, 64, centerZ + z).setType(Material.BEDROCK);
            world.getBlockAt(centerX + 15, 64, centerZ + z).setType(Material.BEDROCK);
        }
        
        plugin.getLogger().info(\"Plataforma do mapa \" + world.getName() + \" construída.\");
    }

    public void saveAllSpawns() {
        // Salvar spawns no config se necessário
        plugin.getLogger().info(\"Spawns salvos.\");
    }

    public Location getSpawn(String worldName) {
        return worldSpawns.get(worldName);
    }

    public World getWorld(String name) {
        return Bukkit.getWorld(name);
    }
}