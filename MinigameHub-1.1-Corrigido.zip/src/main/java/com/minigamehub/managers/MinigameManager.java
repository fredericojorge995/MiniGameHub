package com.minigamehub.managers;

import com.minigamehub.MinigameHub;
import com.minigamehub.games.Minigame;
import com.minigamehub.utils.MsgUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

public class MinigameManager {

    private final MinigameHub plugin;
    private final Map<String, Minigame> minigames = new LinkedHashMap<>();

    public MinigameManager(MinigameHub plugin) {
        this.plugin = plugin;
    }

    public void loadAll() {
        minigames.clear();
        
        ConfigurationSection section = plugin.getConfig().getConfigurationSection(\"minigames\");
        if (section == null) {
            plugin.getLogger().warning(\"Secao 'minigames' nao encontrada no config!\");
            return;
        }

        for (String key : section.getKeys(false)) {
            try {
                ConfigurationSection mg = section.getConfigurationSection(key);
                if (mg == null) {
                    plugin.getLogger().warning(\"Minigame \" + key + \" sem configuracao valida.\");
                    continue;
                }

                String displayName = mg.getString(\"display-name\", \"&f\" + key);
                String lobbyWorld = mg.getString(\"lobby-world\", key + \"_lobby\");
                
                int x = mg.getInt(\"spawn.x\", 0);
                int y = mg.getInt(\"spawn.y\", 65);
                int z = mg.getInt(\"spawn.z\", 0);
                
                // Obter mundo do lobby
                World world = Bukkit.getWorld(lobbyWorld);
                if (world == null) {
                    // Usar hub_main como fallback temporario
                    world = Bukkit.getWorld(\"hub_main\");
                }
                
                Location spawn = new Location(world, x, y, z);
                java.util.List<String> maps = mg.getStringList(\"maps\");

                Minigame minigame = new Minigame(key, displayName, lobbyWorld, spawn, maps);
                minigames.put(key, minigame);
                
                plugin.getLogger().info(\"Carregado: \" + key + \" com \" + maps.size() + \" mapas\");
                
            } catch (Exception e) {
                plugin.getLogger().severe(\"Erro ao carregar minigame \" + key + \": \" + e.getMessage());
            }
        }
        
        plugin.getLogger().info(\"Total de minigames carregados: \" + minigames.size());
    }

    public Minigame get(String key) {
        return minigames.get(key.toLowerCase());
    }

    public Collection<Minigame> all() {
        return minigames.values();
    }

    public Minigame getRandom() {
        if (minigames.isEmpty()) return null;
        Object[] arr = minigames.values().toArray();
        return (Minigame) arr[(int) (Math.random() * arr.length)];
    }
}