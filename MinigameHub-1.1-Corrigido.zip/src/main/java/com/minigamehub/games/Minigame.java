package com.minigamehub.games;

import org.bukkit.Location;
import java.util.List;

public class Minigame {

    private final String key;
    private final String displayName;
    private final String lobbyWorld;
    private final Location lobbySpawn;
    private final List<String> maps;

    public Minigame(String key, String displayName, String lobbyWorld, Location lobbySpawn, List<String> maps) {
        this.key = key;
        this.displayName = displayName;
        this.lobbyWorld = lobbyWorld;
        this.lobbySpawn = lobbySpawn;
        this.maps = maps;
    }

    public String getKey() {
        return key;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getLobbyWorld() {
        return lobbyWorld;
    }

    public Location getLobbySpawn() {
        return lobbySpawn;
    }

    public List<String> getMaps() {
        return maps;
    }

    public String getRandomMap() {
        if (maps == null || maps.isEmpty()) {
            return null;
        }
        int index = (int) (Math.random() * maps.size());
        return maps.get(index);
    }
}