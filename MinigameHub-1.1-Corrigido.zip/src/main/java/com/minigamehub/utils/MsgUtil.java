package com.minigamehub.utils;

import com.minigamehub.MinigameHub;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public class MsgUtil {

    /**
     * Traduz códigos de cores alternativas (& para §)
     */
    public static String color(String message) {
        if (message == null) return \"\";
        return ChatColor.translateAlternateColorCodes('&', message);
    }

    /**
     * Obtém o prefixo do plugin do config
     */
    public static String prefix() {
        String p = MinigameHub.getInstance().getConfig().getString(\"messages.prefix\", \"&8[&6MG&8] &r\");
        return color(p);
    }

    /**
     * Envia mensagem com prefixo
     */
    public static void send(CommandSender sender, String message) {
        if (message == null) return;
        sender.sendMessage(prefix() + color(message));
    }

    /**
     * Envia mensagem sem prefixo (crua)
     */
    public static void sendRaw(CommandSender sender, String message) {
        if (message == null) return;
        sender.sendMessage(color(message));
    }

    /**
     * Envia mensagem com replacements (ex: %player%, %map%)
     */
    public static String fromConfig(String path, String... replacements) {
        String msg = MinigameHub.getInstance().getConfig().getString(path, \"\");
        if (msg != null && replacements != null) {
            for (int i = 0; i < replacements.length - 1; i += 2) {
                msg = msg.replace(replacements[i], replacements[i + 1]);
            }
        }
        return msg;
    }
}