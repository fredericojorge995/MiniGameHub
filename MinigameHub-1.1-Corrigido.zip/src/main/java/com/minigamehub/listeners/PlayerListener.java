package com.minigamehub.listeners;

import com.minigamehub.MinigameHub;
import com.minigamehub.managers.ArenaManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;

public class PlayerListener implements Listener {

    private final MinigameHub plugin;

    public PlayerListener(MinigameHub plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        
        // Teleportar para o hub ao entrar
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                String hubWorldName = plugin.getConfig().getString(\"hub.world\", \"hub_main\");
                org.bukkit.World hubWorld = Bukkit.getWorld(hubWorldName);
                
                if (hubWorld == null) {
                    hubWorld = plugin.getWorldManager().createOrLoadWorld(hubWorldName);
                }
                
                if (hubWorld != null) {
                    int x = plugin.getConfig().getInt(\"hub.spawn.x\", 5);
                    int y = plugin.getConfig().getInt(\"hub.spawn.y\", 83);
                    int z = plugin.getConfig().getInt(\"hub.spawn.z\", -85);
                    float yaw = plugin.getConfig().getFloat(\"hub.spawn.yaw\", 0f);
                    float pitch = plugin.getConfig().getFloat(\"hub.spawn.pitch\", 0f);
                    
                    Location spawn = new Location(hubWorld, x, y, z, yaw, pitch);
                    player.teleport(spawn);
                    
                    player.sendMessage(ChatColor.GREEN + \"Bem-vindo ao servidor!\");
                    player.sendMessage(ChatColor.GRAY + \"Use \" + ChatColor.YELLOW + \"/mghelp\" + ChatColor.GRAY + \" para ver os comandos.\");
                }
            }
        }, 20L); // 1 segundo de delay
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        
        // Remover jogador do lobby ao sair
        ArenaManager arenaManager = plugin.getArenaManager();
        String arenaKey = arenaManager.getPlayerArena(player);
        if (arenaKey != null) {
            arenaManager.leaveLobby(player, false);
        }
    }

    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        
        // Respawn no hub
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                String hubWorldName = plugin.getConfig().getString(\"hub.world\", \"hub_main\");
                org.bukkit.World hubWorld = Bukkit.getWorld(hubWorldName);
                
                if (hubWorld != null) {
                    int x = plugin.getConfig().getInt(\"hub.spawn.x\", 5);
                    int y = plugin.getConfig().getInt(\"hub.spawn.y\", 83);
                    int z = plugin.getConfig().getInt(\"hub.spawn.z\", -85);
                    
                    Location spawn = new Location(hubWorld, x, y, z);
                    event.setRespawnLocation(spawn);
                }
            }
        }, 1L);
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        // Reduzir dano no hub e lobbies para evitar mortes acidentais
        if (event.getEntity() instanceof Player) {
            Player player = (Player) event.getEntity();
            String worldName = player.getWorld().getName();
            
            // Verificar se é mundo do hub ou lobby
            String hubWorld = plugin.getConfig().getString(\"hub.world\", \"hub_main\");
            if (worldName.equals(hubWorld) || worldName.endsWith(\"_lobby\")) {
                // Reduzir dano pela metade em lobbies
                event.setDamage(event.getDamage() * 0.5);
            }
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        String worldName = player.getWorld().getName();
        
        // Permitir quebra de blocos apenas em mundos de jogo
        String hubWorld = plugin.getConfig().getString(\"hub.world\", \"hub_main\");
        
        // Bloquear quebra no hub e lobbies
        if (worldName.equals(hubWorld) || worldName.endsWith(\"_lobby\")) {
            if (!player.hasPermission(\"minigamehub.admin\")) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        String worldName = player.getWorld().getName();
        
        String hubWorld = plugin.getConfig().getString(\"hub.world\", \"hub_main\");
        
        // Bloquear colocar blocos no hub e lobbies
        if (worldName.equals(hubWorld) || worldName.endsWith(\"_lobby\")) {
            if (!player.hasPermission(\"minigamehub.admin\")) {
                event.setCancelled(true);
            }
        }
    }
}