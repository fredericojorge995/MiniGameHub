#!/bin/bash

# ====================================
# MinigameHub - Script de Construção
# ====================================
# Requisitos: Java 17+ e Maven
# Uso: ./build.sh

echo \"========================================\"
echo \"  MinigameHub v1.0 - Build Script\"
echo \"========================================\"
echo \"\"

# Verificar Java
if ! command -v java &> /dev/null; then
    echo \"ERRO: Java não encontrado!\"
    echo \"Instale o Java 17+ para compilar o plugin.\"
    exit 1
fi

JAVA_VERSION=$(java -version 2>&1 | head -1)
echo \"Java encontrado: $JAVA_VERSION\"

# Verificar Maven
if ! command -v mvn &> /dev/null; then
    echo \"ERRO: Maven não encontrado!\"
    echo \"Instale o Maven para compilar o plugin.\"
    echo \"Ubuntu/Debian: sudo apt install maven\"
    exit 1
fi

echo \"\"
echo \"Compilando o plugin...\"
echo \"\"

# Limpar builds anteriores
mvn clean

# Compilar
mvn package -DskipTests

# Verificar resultado
if [ -f \"target/MinigameHub-1.0.jar\" ]; then
    echo \"\"\"
    echo \"========================================\"
    echo \"  SUCESSO! Plugin compilado!\"
    echo \"========================================\"
    echo \"\"\"
    echo \"JAR gerado em: target/MinigameHub-1.0.jar\"
    echo \"\"\"
    echo \"Copie para a pasta 'plugins' do seu servidor.\"
else
    echo \"\"\"
    echo \"========================================\"
    echo \"  ERRO: Falha na compilação!\"
    echo \"========================================\"
    exit 1
fi